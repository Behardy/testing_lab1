"use strict";
const express = require("express");
const cart = require("./cart-items");
const page = express.Router();

page.get("/cart-items",(req,res)=>{
    res.json(cart);
});

page.post("/cart-items",(req,res)=>{
   console.log(req.body);
   cartitems.push(req.body);
    res.json(cart);
});
page.put("/cart-items/:id", (req, res) => {
    console.log(req.body, req.params.id);

    res.json(cart);
});
page.delete("/cart-items/:id",(req,res)=>{
console.log(req.params.id);

res.json(cart);
});



module.exports = page;